﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using StudentsPersonalData.Classes;
using Excel = Microsoft.Office.Interop.Excel;

namespace StudentsPersonalData.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageListStudent.xaml
    /// </summary>
    public partial class PageListStudent : Page
    {
        public PageListStudent()
        {
            InitializeComponent();
            var currentUser = StudentsDBEntities.GetContext().Student.ToList();
            LViewUser.ItemsSource = currentUser;
        }
        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddEditPagq((sender as Button).DataContext as Student));
        }
        private void BtnExcel_Click(object sender, RoutedEventArgs e)
        {


            //объект Excel
            var app = new Excel.Application();

            //книга 
            Excel.Workbook wb = app.Workbooks.Add();
            //лист
            Excel.Worksheet worksheet = app.Worksheets.Item[1];
            int indexRows = 1;
            //ячейка
            worksheet.Cells[1][indexRows] = "Номер";
            worksheet.Cells[2][indexRows] = "Фамилия";
            worksheet.Cells[3][indexRows] = "Имя";
            worksheet.Cells[4][indexRows] = "Отчество";
            worksheet.Cells[5][indexRows] = "Дата рождения";
            worksheet.Cells[6][indexRows] = "Год поступления";
            worksheet.Cells[7][indexRows] = "Стипендия";
            worksheet.Cells[8][indexRows] = "Специальность";
            worksheet.Cells[9][indexRows] = "Группа";
            //цикл по данным из таблиц

            var printItems = LViewUser.Items;
            //цикл по данным из списка для печати
            foreach (Student item in printItems)
            {
                worksheet.Cells[1][indexRows + 1] = indexRows;
                worksheet.Cells[2][indexRows + 1] = item.SurName;
                worksheet.Cells[3][indexRows + 1] = item.FirstName;
                worksheet.Cells[4][indexRows + 1] = item.Patron;
                worksheet.Cells[5][indexRows + 1] = item.BirthDate.ToString();
                worksheet.Cells[6][indexRows + 1] = item.EnrollmentYear;
                worksheet.Cells[7][indexRows + 1] = item.Grants;
                worksheet.Cells[8][indexRows + 1] = item.Groupe.Specialization.Specialization1;
                worksheet.Cells[9][indexRows + 1] = item.Groupe.GroupName;
                indexRows++;
            }
            Excel.Range range = worksheet.Range[worksheet.Cells[2][indexRows + 1],
                    worksheet.Cells[9][indexRows + 1]];
            range.ColumnWidth = 30; //ширина столбцов
            range.HorizontalAlignment = Excel.XlHAlign.xlHAlignLeft;//выравнивание по левому краю
            worksheet.Cells[1, 10].Value = "Сумма Стипендий:";
            worksheet.Cells[2, 10].Formula = "=SUM(G2:G10000)";
            worksheet.Cells[3, 10].Value = "Число студентов:";
            worksheet.Cells[4, 10].Formula = "=COUNT(G2:G10000)";


            //показать Excel
            app.Visible = true;

        }
    }
}
