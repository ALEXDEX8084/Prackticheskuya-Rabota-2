﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using StudentsPersonalData.Pages;
using StudentsPersonalData.Classes;
using Excel = Microsoft.Office.Interop.Excel;


namespace StudentsPersonalData.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageStudents.xaml
    /// </summary>
    public partial class PageStudents : Page
    {
        public PageStudents()
        {
            InitializeComponent();
            DGridUsers.ItemsSource = StudentsDBEntities.GetContext().Student.ToList();
            CmbFiltrGroup.ItemsSource = StudentsDBEntities.GetContext().Student.ToList();
            CmbFiltrGroup.SelectedValuePath = "GroupID";
            CmbFiltrGroup.DisplayMemberPath = "Groupe.GroupName";

        }

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        //Редактирование пользователей
        {
            ClassFrame.frmObj.Navigate(new AddEditPagq((sender as Button).DataContext as Student));
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        // Добавление пользователей
        {
            ClassFrame.frmObj.Navigate(new AddEditPagq(null)/*((Person)DGridUsers.SelectedItem)*/);
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            //Удаление нескольких пользователей
            var personForRemoving = DGridUsers.SelectedItems.Cast<Student>().ToList();
            if (MessageBox.Show($"Удалить {personForRemoving.Count()} пользователей?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    StudentsDBEntities.GetContext().Student.RemoveRange(personForRemoving);
                    StudentsDBEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены");
                    DGridUsers.ItemsSource = StudentsDBEntities.GetContext().Student.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {//Динамиеское отображение добавленных или изменённых данных
            if (Visibility == Visibility.Visible)
            {
                StudentsDBEntities.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                DGridUsers.ItemsSource = StudentsDBEntities.GetContext().Student.ToList();
            }
        }

        private void BtnResetAll_Click(object sender, RoutedEventArgs e)
        {
            DGridUsers.ItemsSource = StudentsDBEntities.GetContext().Student.ToList();
        }

        private void CmbFiltrGroup_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int id = Convert.ToInt32(CmbFiltrGroup.SelectedValue);
            DGridUsers.ItemsSource = StudentsDBEntities.GetContext().Student.Where(x => x.GroupID == id).ToList();
        }

        private void RbUp_Checked(object sender, RoutedEventArgs e)
        {
            DGridUsers.ItemsSource = StudentsDBEntities.GetContext().Student.OrderBy(x => x.SurName).ToList();
        }

        private void RbDown_Checked(object sender, RoutedEventArgs e)
        {
            DGridUsers.ItemsSource = StudentsDBEntities.GetContext().Student.OrderByDescending(x => x.SurName).ToList();
        }

        private void CmbFiltr_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CmbFiltr.SelectedIndex == 0)
            {
                DGridUsers.ItemsSource = StudentsDBEntities.GetContext().Student.Where(x => x.Groupe.GroupName == "ИСП20А").ToList();
            }
            else
                            if (CmbFiltr.SelectedIndex == 1)
            {
                DGridUsers.ItemsSource = StudentsDBEntities.GetContext().Student.Where(x => x.Groupe.GroupName == ("ССА20А")).ToList();
            }
            else
                            if (CmbFiltr.SelectedIndex == 2)
            {
                DGridUsers.ItemsSource = StudentsDBEntities.GetContext().Student.Where(x =>x.Groupe.GroupName == ("ТМ22А")).ToList();
            }
        }

        private void TxtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            DGridUsers.ItemsSource = StudentsDBEntities.GetContext().Student.Where(x => x.SurName.ToLower().Contains(TxtSearch.Text.ToLower())).ToList();
        }

        private void BtnToList_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageListStudent());
        }
        //private void BtnExcel_Click(object sender, RoutedEventArgs e)
        //{


        //    //объект Excel
        //    var app = new Excel.Application();

        //    //книга 
        //    Excel.Workbook wb = app.Workbooks.Add();
        //    //лист
        //    Excel.Worksheet worksheet = app.Worksheets.Item[1];
        //    int indexRows = 1;
        //    //ячейка
        //    worksheet.Cells[1][indexRows] = "Номер";
        //    worksheet.Cells[2][indexRows] = "Фамилия";
        //    worksheet.Cells[3][indexRows] = "Имя";
        //    worksheet.Cells[4][indexRows] = "Отчество";
        //    worksheet.Cells[5][indexRows] = "Дата рождения";
        //    worksheet.Cells[6][indexRows] = "Год поступления";
        //    worksheet.Cells[7][indexRows] = "Стипендия";
        //    worksheet.Cells[8][indexRows] = "Специальность";
        //    worksheet.Cells[9][indexRows] = "Группа";
        //    //цикл по данным из таблиц

        //   var printItems = LViewUser.Items;
        //        //цикл по данным из списка для печати
        //        foreach (Student item in printItems)
        //        {
        //        worksheet.Cells[1][indexRows + 1] = indexRows;
        //        worksheet.Cells[2][indexRows + 1] = item.SurName;
        //        worksheet.Cells[3][indexRows + 1] = item.FirstName;
        //        worksheet.Cells[4][indexRows + 1] = item.Patron;
        //        worksheet.Cells[5][indexRows + 1] = item.BirthDate.ToString();
        //        worksheet.Cells[6][indexRows + 1] = item.EnrollmentYear;
        //        worksheet.Cells[7][indexRows + 1] = item.Grants;
        //        worksheet.Cells[8][indexRows + 1] = item.Groupe.Specialization.Specialization1;
        //        worksheet.Cells[9][indexRows + 1] = item.Groupe.GroupName;
        //        indexRows++;
        //        }
        //        Excel.Range range = worksheet.Range[worksheet.Cells[2][indexRows + 1],
        //                worksheet.Cells[5][indexRows + 1]];
        //        range.ColumnWidth = 30; //ширина столбцов
        //        range.HorizontalAlignment = Excel.XlHAlign.xlHAlignLeft;//выравнивание по левому краю

        //        //Excel.Range sumRange = worksheet.Range[worksheet.Cells[10][indexRows]];
        //        //sumRange.Merge();
        //        //sumRange.Value = "Итого:";
        //        //sumRange.HorizontalAlignment = Excel.XlHAlign.xlHAlignRight;
        //        //worksheet.Cells[10][indexRows + 1].Formula = $"="

        //    //показать Excel
        //    app.Visible = true;

        //}
    }
}