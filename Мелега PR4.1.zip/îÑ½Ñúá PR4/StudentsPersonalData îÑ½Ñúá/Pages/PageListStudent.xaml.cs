﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using StudentsPersonalData.Classes;
using Excel = Microsoft.Office.Interop.Excel;
using Word = Microsoft.Office.Interop.Word;

namespace StudentsPersonalData.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageListStudent.xaml
    /// </summary>
    public partial class PageListStudent : Page
    {
        public PageListStudent()
        {
            InitializeComponent();
            var currentUser = StudentsDBEntities.GetContext().Student.ToList();
            LViewUser.ItemsSource = currentUser;
        }
        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddEditPagq((sender as Button).DataContext as Student));
        }
        private void BtnExcel_Click(object sender, RoutedEventArgs e)
        {


            //объект Excel
            var app = new Excel.Application();

            //книга 
            Excel.Workbook wb = app.Workbooks.Add();
            //лист
            Excel.Worksheet worksheet = app.Worksheets.Item[1];
            int indexRows = 1;
            //ячейка
            worksheet.Cells[1][indexRows] = "Номер";
            worksheet.Cells[2][indexRows] = "Фамилия";
            worksheet.Cells[3][indexRows] = "Имя";
            worksheet.Cells[4][indexRows] = "Отчество";
            worksheet.Cells[5][indexRows] = "Дата рождения";
            worksheet.Cells[6][indexRows] = "Год поступления";
            worksheet.Cells[7][indexRows] = "Стипендия";
            worksheet.Cells[8][indexRows] = "Специальность";
            worksheet.Cells[9][indexRows] = "Группа";
            //цикл по данным из таблиц

            var printItems = LViewUser.Items;
            //цикл по данным из списка для печати
            foreach (Student item in printItems)
            {
                worksheet.Cells[1][indexRows + 1] = indexRows;
                worksheet.Cells[2][indexRows + 1] = item.SurName;
                worksheet.Cells[3][indexRows + 1] = item.FirstName;
                worksheet.Cells[4][indexRows + 1] = item.Patron;
                worksheet.Cells[5][indexRows + 1] = item.BirthDate.ToString();
                worksheet.Cells[6][indexRows + 1] = item.EnrollmentYear;
                worksheet.Cells[7][indexRows + 1] = item.Grants;
                worksheet.Cells[8][indexRows + 1] = item.Groupe.Specialization.Specialization1;
                worksheet.Cells[9][indexRows + 1] = item.Groupe.GroupName;
                indexRows++;
            }
            Excel.Range range = worksheet.Range[worksheet.Cells[2][indexRows + 1],
                    worksheet.Cells[9][indexRows + 1]];
            range.ColumnWidth = 30; //ширина столбцов
            range.HorizontalAlignment = Excel.XlHAlign.xlHAlignLeft;//выравнивание по левому краю
            worksheet.Cells[1, 10].Value = "Сумма Стипендий:";
            worksheet.Cells[2, 10].Formula = "=SUM(G2:G10000)";
            worksheet.Cells[3, 10].Value = "Число студентов:";
            worksheet.Cells[4, 10].Formula = "=COUNT(G2:G10000)";


            //показать Excel
            app.Visible = true;

        }
        private void BtnExportToWord_Click(object sender, RoutedEventArgs e)
        {
            var application = new Word.Application();
            Word.Document document = application.Documents.Add();
            List<Student> printItems = new List<Student>();

            for (int i = 0; i < LViewUser.Items.Count; i++)
                printItems.Add((Student)LViewUser.Items[i]);
            int j = 0;

            Word.Paragraph userParagrapth = document.Paragraphs.Add();
            Word.Range userRange = userParagrapth.Range;
            userRange.Text = "Студенты";


            Word.Paragraph tableParagraph = document.Paragraphs.Add();
            Word.Range tableRange = tableParagraph.Range;
            Word.Table grouptable = document.Tables.Add(tableRange, printItems.Count() + 1, 8);
            grouptable.Borders.InsideLineStyle = grouptable.Borders.OutsideLineStyle
                = Word.WdLineStyle.wdLineStyleSingle;
            grouptable.Range.Cells.VerticalAlignment = Word.WdCellVerticalAlignment.wdCellAlignVerticalCenter;

            foreach (var user in printItems)
            {
                Word.Range cellRange;

                cellRange = grouptable.Cell(1, 1).Range;
                cellRange.Text = "Фамилия";
                cellRange = grouptable.Cell(1, 2).Range;
                cellRange.Text = "Имя";
                cellRange = grouptable.Cell(1, 3).Range;
                cellRange.Text = "Отчество";
                cellRange = grouptable.Cell(1, 4).Range;
                cellRange.Text = "Год Рождения";
                cellRange = grouptable.Cell(1, 5).Range;
                cellRange.Text = "Год поступления";
                cellRange = grouptable.Cell(1, 6).Range;
                cellRange.Text = "Стипендия";
                cellRange = grouptable.Cell(1, 7).Range;
                cellRange.Text = "Специализация";
                cellRange = grouptable.Cell(1, 8).Range;
                cellRange.Text = "Группа";

                grouptable.Rows[1].Range.Bold = 1;
                grouptable.Rows[1].Range.ParagraphFormat.Alignment = Word.WdParagraphAlignment.wdAlignParagraphCenter;

                cellRange = grouptable.Cell(j + 2, 1).Range;
                cellRange.Text = user.SurName;
                Word.InlineShape imageShape = cellRange.InlineShapes.AddPicture(AppDomain.CurrentDomain.BaseDirectory
                 + "..\\..\\" + user.FaceImage);
                imageShape.Width = imageShape.Height = 40;
                cellRange.ParagraphFormat.Alignment = Word.WdParagraphAlignment.wdAlignParagraphCenter;

                cellRange = grouptable.Cell(j + 2, 2).Range;
                cellRange.Text = user.FirstName;

                cellRange = grouptable.Cell(j + 2, 3).Range;
                cellRange.Text = user.Patron;

                cellRange = grouptable.Cell(j + 2, 4).Range;
                cellRange.Text = user.BirthDate.ToString();

                cellRange = grouptable.Cell(j + 2, 5).Range;
                cellRange.Text = user.EnrollmentYear.ToString();

                cellRange = grouptable.Cell(j + 2, 6).Range;
                cellRange.Text = user.Grants.ToString();

                cellRange = grouptable.Cell(j + 2, 7).Range;
                cellRange.Text = user.Groupe.Specialization.Specialization1;

                cellRange = grouptable.Cell(j + 2, 8).Range;
                cellRange.Text = user.Groupe.GroupName;
                j++;

            }
            application.Visible = true;
        }
    }
}
